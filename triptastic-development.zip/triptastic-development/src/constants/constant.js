export const BASE_URL = "http://localhost:5000"

export const listQuery = {
    QueryType: "paginated",
    pageSize: 10,
    currentPage: 1,
    parameters: [],
};
export const SERVER_ERROR = "SERVER ERROR!!";
