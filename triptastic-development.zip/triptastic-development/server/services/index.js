module.exports = {
  FlightService: require("./flight-service"),
  UserService: require("./user-service"),
  BookingService: require("./booking-service"),
  AirportService: require("./airport-service"),
  ContactService: require("./contact-service"),
};
